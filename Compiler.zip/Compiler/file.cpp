#include <iostream>
#include <string>
using namespace std;
int main(){
	string str = "Hello" ; 
	str = str + "1" ; 
	cout << ( str ) ; 
	str = 21 + 2 + 18 ; 
	cout << ( str ) ; 
	const string worldString = "World" ; 
	const int answerNumber = 42 ; 
	cout << ( worldString + answerNumber ) ; 
	cout << ( worldString - answerNumber ) ; 
	const float pi = 3.14 ; 
	cout << ( pi + answerNumber ) ; 
	const string numberString = "134" ; 
	cout << ( numberString + answerNumber ) ; 
	cout << ( numberString - answerNumber ) ; 
	const string name = "ASd" ; 
	cout << ( "Your name is " + name ) ; 
}